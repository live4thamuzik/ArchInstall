#!/bin/bash
# lvm.sh - LVM partitioning strategy with ESP + XBOOTLDR (UEFI) or boot partition (BIOS)
set -euo pipefail

# Source common utilities
SCRIPT_DIR="$(dirname "${BASH_SOURCE[0]}")"
source "$SCRIPT_DIR/../disk_utils.sh"

# Execute LVM partitioning strategy
execute_lvm_partitioning() {
    echo "=== PHASE 1: LVM Partitioning (ESP + XBOOTLDR) ==="
    log_info "Starting LVM partitioning with ESP + XBOOTLDR for $INSTALL_DISK..."
    
    # Validate requirements
    validate_partitioning_requirements

    # Wipe disk with explicit confirmation
    wipe_disk "$INSTALL_DISK" "CONFIRMED"

    local current_start_mib=1
    local part_num=1
    
    # Create partition table
    create_partition_table "$INSTALL_DISK"
    
    # ESP Partition (for UEFI only) - mounted to /efi
    if [ "$BOOT_MODE" = "UEFI" ]; then
        create_esp_partition "$INSTALL_DISK" "$part_num" "100"
        current_start_mib=$((current_start_mib + 100))
        part_num=$((part_num + 1))

        # XBOOTLDR Partition - mounted to /boot
        create_xbootldr_partition "$INSTALL_DISK" "$part_num" "1024"
        current_start_mib=$((current_start_mib + 1024))
        part_num=$((part_num + 1))
    else
        # BIOS: Boot partition - mounted to /boot
        create_boot_partition "$INSTALL_DISK" "$part_num" "1024"
        current_start_mib=$((current_start_mib + 1024))
        part_num=$((part_num + 1))
    fi
    
    # Swap partition (if requested)
    if [ "$WANT_SWAP" = "yes" ]; then
        local swap_size_mib=$(get_swap_size_mib)
        create_swap_partition "$INSTALL_DISK" "$part_num" "$swap_size_mib"
        current_start_mib=$((current_start_mib + swap_size_mib))
        part_num=$((part_num + 1))
    fi
    
    # LVM partition
    log_info "Creating LVM partition..."
    if [ "$BOOT_MODE" = "UEFI" ]; then
        sgdisk -n "$part_num:0:0" -t "$part_num:$LVM_PARTITION_TYPE" "$INSTALL_DISK" || error_exit "Failed to create LVM partition."
    else
        printf "n\np\n$part_num\n\n\nw\n" | fdisk "$INSTALL_DISK" || error_exit "Failed to create LVM partition."
    fi
    partprobe "$INSTALL_DISK"
    local lvm_part=$(get_partition_path "$INSTALL_DISK" "$part_num")
    
    # Create LVM setup
    log_info "Setting up LVM..."
    pvcreate "$lvm_part" || error_exit "Failed to create physical volume."
    vgcreate arch "$lvm_part" || error_exit "Failed to create volume group."
    
    # Create logical volumes
    log_info "Creating logical volumes..."
    local root_size_gb=50
    lvcreate -L "${root_size_gb}G" -n root arch || error_exit "Failed to create root logical volume."
    
    if [ "$WANT_HOME_PARTITION" = "yes" ]; then
        lvcreate -l 100%FREE -n home arch || error_exit "Failed to create home logical volume."
    fi
    
    # Format logical volumes
    log_info "Formatting logical volumes..."
    format_filesystem "/dev/arch/root" "$ROOT_FILESYSTEM_TYPE"
    capture_device_info "root" "/dev/arch/root"
    safe_mount "/dev/arch/root" "/mnt"

    if [ "$WANT_HOME_PARTITION" = "yes" ]; then
        format_filesystem "/dev/arch/home" "$HOME_FILESYSTEM_TYPE"
        capture_device_info "home" "/dev/arch/home"
        mkdir -p /mnt/home
        safe_mount "/dev/arch/home" "/mnt/home"
    fi
    
    # Store LVM device mapping
    LVM_DEVICES_MAP["arch_root"]="/dev/arch/root"
    if [ "$WANT_HOME_PARTITION" = "yes" ]; then
        LVM_DEVICES_MAP["arch_home"]="/dev/arch/home"
    fi
    
    log_partitioning_complete "LVM ESP + XBOOTLDR"
}
